// =============================================================
// GOOGLE APPS SCRIPT - Copie TUDO e cole no Apps Script
// Caminho: Planilha > Extensões > Apps Script > Cole aqui
// =============================================================

function doGet() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("status prospecção");
  if (!sheet) {
    return ContentService
      .createTextOutput(JSON.stringify({ error: "Aba 'status prospecção' não encontrada" }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var rows = [];

  for (var i = 1; i < data.length; i++) {
    var row = data[i];
    var nome = String(row[0] || "").trim();
    if (!nome) continue;

    rows.push({
      nome: nome,
      canal: String(row[1] || "").trim(),
      status: String(row[2] || "").trim(),
      dataContato: row[3] ? Utilities.formatDate(new Date(row[3]), Session.getScriptTimeZone(), "yyyy-MM-dd") : "",
      respondeu: String(row[4] || "").trim(),
      dataFollowUp: row[5] ? Utilities.formatDate(new Date(row[5]), Session.getScriptTimeZone(), "yyyy-MM-dd") : "",
      prioridade: String(row[6] || "").trim(),
      midiaKit: String(row[7] || "").trim(),
      proximoPasso: String(row[8] || "").trim(),
      proposta: String(row[9] || "").trim()
    });
  }

  var output = JSON.stringify({ data: rows, updatedAt: new Date().toISOString() });
  return ContentService
    .createTextOutput(output)
    .setMimeType(ContentService.MimeType.JSON);
}
